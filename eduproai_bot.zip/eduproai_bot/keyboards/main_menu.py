from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def main_menu_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 Taqdimot"), KeyboardButton(text="📄 Referat")],
            [KeyboardButton(text="📝 Test"), KeyboardButton(text="🧩 Krossword")],
            [KeyboardButton(text="🎮 Quiz"), KeyboardButton(text="🖼 Rasm → PDF")],
            [KeyboardButton(text="💼 Balans"), KeyboardButton(text="⭐ VIP obuna")],
            [KeyboardButton(text="🆘 Qo‘llab-quvvatlash"), KeyboardButton(text="🌍 Til sozlamalari")],
        ],
        resize_keyboard=True
    )

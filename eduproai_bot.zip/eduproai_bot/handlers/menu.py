from aiogram import Router
from aiogram.types import Message

menu_router = Router()

@menu_router.message()
async def menu_handler(message: Message):
    await message.answer("Bu bo‘lim hali ishlab chiqilmoqda 🚧")

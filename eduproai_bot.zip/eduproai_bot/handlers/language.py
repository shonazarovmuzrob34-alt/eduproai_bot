from aiogram import Router, F
from aiogram.types import CallbackQuery

from keyboards.main_menu import main_menu_keyboard

language_router = Router()

@language_router.callback_query(F.data.startswith("lang_"))
async def set_language(callback: CallbackQuery):
    await callback.answer("Til o‘rnatildi ✅")
    await callback.message.answer(
        "Asosiy menyu 👇",
        reply_markup=main_menu_keyboard()
    )

from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from keyboards.language import language_keyboard

start_router = Router()

@start_router.message(CommandStart())
async def start_handler(message: Message):
    await message.answer(
        "👋 EduProAI ga xush kelibsiz!\n\n"
        "Davom etish uchun tilni tanlang 🌍",
        reply_markup=language_keyboard()
    )
